# Pajak-Motor-Dengan-Java
Menyelesaikan tugas UAS Mata Kuliah Pemrograman Open Source
